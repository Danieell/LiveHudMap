Extract both dirs in your WurmLauncher dir.
Set your default server in the property file.